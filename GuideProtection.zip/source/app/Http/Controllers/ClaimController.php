<?php

namespace App\Http\Controllers;

use App\Models\Claim;
use Illuminate\Http\Request;

class ClaimController extends Controller
{
    //
    public function index(){
        $claims=Claim::groupBy('store_ordernumber')->get();
        return view('admin.claims.index',['claims'=>$claims]);
    }
}
