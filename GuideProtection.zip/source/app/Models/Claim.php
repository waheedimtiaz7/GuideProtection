<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Claim extends Model
{
    use HasFactory;
    protected $fillable=[
        'incident_type',
        'incident_description',		
        'store_id',	
        'store_ordernumber',	
        'cart_ordernumber',
        'cart_trackingnumber',
        'order_id',
        'orderdate',
        'customer_reported_trackno',
        'customer_lastname',
        'customer_email',
        'customer_phone',
        'shipping_addresss_1',
        'shipping_addresss_2',
        'shipping_city',
        'shipping_state',
        'shipping_zip',
        'shipping_country',
        'shipping_carrier_method',
        'reorder_trackingnumber',
        'reorder_cartnumber',
        'reorder_storenumber',
        'reorder_status',
        'claim_status',
        'claim_rep',
        'gp_origord_shiptrackno',
        'gp_reorderno',
        'gp_reorder_trackno',
        'hold_until_date	date',
        'notes'
    ];
}
