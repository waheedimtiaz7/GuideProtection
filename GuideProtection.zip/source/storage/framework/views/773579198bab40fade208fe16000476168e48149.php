<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body style="background-color: #ffffff">
<div class="wrapper">
    <?php echo $__env->yieldContent('content'); ?>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<?php echo $__env->yieldContent('script'); ?>
</html><?php /**PATH C:\xampp\htdocs\GuideProtection\source\resources\views/layouts/app.blade.php ENDPATH**/ ?>