<?php return array (
  'login' => 'App\\Http\\Livewire\\Login',
);